package juego.tablero;

public enum Movimiento {

	ARRIBA,
	ABAJO,
	IZQUIERDA,
	DERECHA,
	ADELANTE,
	ATRAS,
}
